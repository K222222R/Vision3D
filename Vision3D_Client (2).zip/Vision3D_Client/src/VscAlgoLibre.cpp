///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///



/*

A LIRE AVANT D'UTILISER L'ALGO LIBRE :
----------------------------------------

Toutes les formes (points, axes, zones,...) doivent �tre cr��es depuis l'IHM. 
Il est interdit de cr�er des formes depuis l'algo libre. Les fonctions suivantes ont donc �t� supprim�es :
- newArea, 
- newAxis, 
- newPointRef, 
- newPointChild, 
- newPointAxis

La fonction "VscAlgoLibre::init" est appel�e une seule fois au d�marrage de la Vision. 
Cette fonction permet d'indiquer � la vision si une forme doit �tre mis � jour par l'algo libre.

Pour cela il faut r�cup�rer une formes existantes avec les fonctions suivantes :
- getArea
- getAxis
- getPoint
- getPointRef
- getPointArea
- getPointChild
- getPointAxis

Puis appeler la fonction "setExternal" en donnant en param�tre la callback d'appel.
Cette "callback" sera appel�e lors de la mise � jour de l'arbre des formes.

Exemple :

VscPoint* l_ptPoint = getPoint("Mon Point 1");
if (l_ptPoint != nullptr)
{
	l_ptPoint->setExternal(&VscAlgoLibre::update_Point_Point1);
}

Toutes les formes misent � jour depuis l'algo libre ne sont plus disponible depuis l'ihm. 
Dans l'IHM tous les param�tres sont desactiv�s et une case � cocher indique que cette 
forme est mise � jour depuis l'algo libre.

Dans le cas ou la callback aurait besoin qu'un certains nombres de forme soient � jour avant son propre appel,
alors il faudra l'indiquer.

Exemple :
Dans la callback de "Mon Point 1", il faut que "Mon point 2" soient d�ja � jour.

VscPoint* l_ptPoint = getPoint("Mon Point 1");
if (l_ptPoint != nullptr)
{
	l_ptPoint->setParent(getPoint("Mon Point 2"));
	l_ptPoint->setExternal(&VscAlgoLibre::update_Point_Point1);
}

Les callback doivent prendre 2 param�tres : Un pointeur sur elle m�me ainsi que la matrice de l'image.
La callback permet de mettre � jour tous les param�tres d'entr�e.

Exemple :

void VscAlgoLibre::update_Point_Point1(VscShape * p_ptShape, VscMatZ * p_cvMatImageZ)
{
	VscPointRef * l_ptPoint = dynamic_cast <VscPointRef *>(p_ptShape);

	l_ptPoint->setXY(cv::Point(20, 50)); // Force le point en X=20 et Y=50

}

Mise � jour du 31 Mars :

ATTENTION : il y a encore une rupture de compatibilit� avec le fichier config.json. Il faut donc repartir avec un fichier config.json vierge.

La fonction VscAlgoLibre::update a �t� renomm� en VscAlgoLibre::updateShapeCompleted.

Les callback retournent void et non bool (comme dans la version pr�c�dente)

L'API pour les points (fils) a �t� revue, voici les nouvelles fonctions :
void setDistanceFixedValue(int p_iFixedValue);							<---- Damien tu as besoin de cette fonction pour fixer ton coefficient sur ton axe (comme vu ensemble par telephone)
void setDistanceFrontHigh(int p_iHeight, int p_iWidth, int p_iNbOcc);
void setDistanceFrontLow(int p_iHeight, int p_iWidth, int p_iNbOcc);
void setDistanceFrontHighOrLow(int p_iHeight, int p_iWidth, int p_iNbOcc);
void setDirectionFixedValue(int p_iFixedValue);
void setDirectionFrontHigh(int p_iHeight, int p_iWidth, int p_iNbOcc);
void setDirectionFrontLow(int p_iHeight, int p_iWidth, int p_iNbOcc);
void setDirectionFrontHighOrLow(int p_iHeight, int p_iWidth, int p_iNbOcc);

L'API pour les points (fils d'un axe), dispose de cette fonction en plus :
setDistanceFixedPercent(int p_iFixedPercent); <-- Pour fixer la valeur en pourcentage

Le compteur d'image est affich� et envoy� en Modbus dans le registre 1.

Pour pouvoir corriger un point ou que celui ci g�n�re une alarme, il faut appeler setChecked
Exemple : l_ptPointAlgo1->setChecked(true);

Pour qu'une forme soit OK ou NOK il faut appeler (� partir de la callback ou de la fonction VscAlgoLibre::updateShapeCompleted) les fonctions :
setOk();
setNok();

Exemple : 
if (l_ptAlgo2->getX() < 200)
{
	l_ptAlgo2->setOk();
}
else
{
	l_ptAlgo2->setNok();
}

L'exemple fourni par le fichier config.json g�n�re une alarme. Cette alarme peut �tre ignor�e (en appuyant sur le bouton). 
Pour corriger cette alarme, il faut cliquer dans la zone image. Ceci permet de repositionner le point. En repositionnant le point "algo2" sur la gauche
X<200, l'alarme sera corrig�e, elle ne sera alors plus affich�e. Si vous recliquez dans la zone image, vous passez alors en mode correction. 
L'utilisateur devra alors choisir parmi une liste de point � corriger.

J'attends vos retour concernant l'IHM.


*/




#include "VscAlgoLibre.h"

#include "VscPointRef.h"
#include "VscPointArea.h"
#include "VscPointChildren.h"
#include "VscPointOfAxis.h"
#include "VscArea.h"
#include "VscAxis.h"
#include "VscDebug.h"
#include "VscItfExterneModbus.h"
#include "VscImageZ.h"
#ifdef ALGO_CONTOUR
#include "Vision3D.h"
#endif



VscAlgoLibre::VscAlgoLibre()
{
	m_bInit = true;
}


VscAlgoLibre::~VscAlgoLibre()
{
}


//
// Appel� une seule fois au demarrage apr�s le chargement du fichier de configuration
// ATTENTION : � ne pas effacer des informations pr�sentes dans le fichier de configuration
//
void VscAlgoLibre::init()
{
#if 0
	//=========pour mise � jour de point "pointCloaque"=========
	VscPointOfAxis* l_ptPointCloaque = getPointAxis("pointCloaque");
	if (l_ptPointCloaque != nullptr)
	{
		l_ptPointCloaque->addParent(getAxis("axeCalibre"));
		l_ptPointCloaque->setFirstPoint(true);
		l_ptPointCloaque->setExported(false);
		l_ptPointCloaque->setChecked(false);
		l_ptPointCloaque->setPreview(true);
		l_ptPointCloaque->setExternal(&VscAlgoLibre::update_pCloiaque);
	}
#endif // 0

	

}

//
// CALLBACK pour mise � jour de point "pointCloaque"
//
void VscAlgoLibre::update_pCloiaque(VscShape* p_ptShape, VscMatZ* p_cvMatImageZ)
{
	VscPointOfAxis* l_ptPointCloaque = dynamic_cast <VscPointOfAxis*>(p_ptShape);
	VscAssert(l_ptPointCloaque != nullptr);

	VscAxis* l_axeCalibre = dynamic_cast <VscAxis*>(l_ptPointCloaque->getParent("axeCalibre"));
	VscAssert(l_axeCalibre != nullptr);
	l_ptPointCloaque->setDistanceFixedValue(l_axeCalibre->getDistanceMM() * 0.08);//coeff point cloaque sur axeMilieux par apport � l'axe calibre
}


//
// Appel� apr�s chaque mise � jour d'une image
//
void VscAlgoLibre::updateShapeCompleted(VscMatZ* p_cvMat)
{
	

}

//
// Appel� lors de la mise � jour les registres du modbus
//
void VscAlgoLibre::recvFromModbus(VscItfExterneModbus* p_ptModbus)
{

}
//
// Appel� pour mettre � jour les registres du modbus
//
void VscAlgoLibre::SendToModbus(VscItfExterneModbus * p_ptModbus)
{
#if 1
	VscPointArea* l_ptpointcroupion = getPointArea("pCroupion");
	if (nullptr != l_ptpointcroupion)
		p_ptModbus->setXYZ(3, l_ptpointcroupion->getX_MM(), l_ptpointcroupion->getY_MM(), l_ptpointcroupion->getZ_MM());

	VscPointOfAxis* l_ptPointCloaque = getPointAxis("pointCloaque");
	if (nullptr != l_ptPointCloaque)
		p_ptModbus->setXYZ(6, l_ptPointCloaque->getX_MM(), l_ptPointCloaque->getY_MM(), l_ptPointCloaque->getZ_MM());

	VscAxis* l_pAxis = getAxis("axeCalibre");
	if (nullptr != l_pAxis)
		p_ptModbus->setValue(9, l_pAxis->getDistanceMM());

	int l_iImageNumber = ((VscImageZ*)p_ptModbus->getImage())->getImageNumber();
	p_ptModbus->setRegister(1, l_iImageNumber);
#endif // 0
}


//
// Appel� pour faire un affichage sp�cifique
//
void VscAlgoLibre::specialDisplay(VscMatZ * p_cvMat, cv::Mat & p_matRun, cv::Mat & p_matEditor, cv::Mat & p_matCalib)
{
	VscPointOfAxis* l_ptPoint1 = getPointAxis("pointCloaque");

	if (nullptr != l_ptPoint1)
	{
		// Exemple d'affichage d'un cercle
		cv::Point center(l_ptPoint1->getX() * p_cvMat->getScale(), l_ptPoint1->getY() * p_cvMat->getScale());
		circle(p_matEditor, center, 20, cv::Scalar(0, 0, 0), 3);
		circle(p_matRun, center, 19, cv::Scalar(0, 0, 0), 3);

		// Exemple d'affichage d'un texte
		putText(p_matEditor, "pointCloaque", center + cv::Point(20, 20), cv::FONT_HERSHEY_PLAIN, 0.7, cv::Scalar(0, 0, 255), 1);
		putText(p_matRun, "pointCloaque", center + cv::Point(20, 20), cv::FONT_HERSHEY_PLAIN, 0.7, cv::Scalar(0, 0, 255), 1);
	}
#ifdef ALGO_CONTOUR
	VscArea * l_ptAreaSobel = getArea("sobel");
	VscArea * l_ptAreaLaplace = getArea("laplace");
	VscArea * l_ptAreaCanny = getArea("canny");

	if ((VscShape::getList()->getSelected() == l_ptAreaSobel) && (l_ptAreaSobel != nullptr))
	{
		// SOBEL
		//
		// -----------------------------------------------
		cv::Mat l_matSrc = l_ptAreaSobel->getMat()->getDisplayMatWithShape();

		cv::Mat src, src_gray;
		cv::Mat grad;
		int ksize = 1; // PARAMETRE A MODIFIER
		int scale = 1; // PARAMETRE A MODIFIER
		int delta = 0; // PARAMETRE A MODIFIER
		int ddepth = CV_16S;

		cv::cvtColor(l_matSrc, src_gray, cv::COLOR_BGR2GRAY);

		cv::Mat grad_x, grad_y;
		cv::Mat abs_grad_x, abs_grad_y;
		Sobel(src_gray, grad_x, ddepth, 1, 0, ksize, scale, delta, cv::BORDER_DEFAULT);
		Sobel(src_gray, grad_y, ddepth, 0, 1, ksize, scale, delta, cv::BORDER_DEFAULT);

		// converting back to CV_8U
		convertScaleAbs(grad_x, abs_grad_x);
		convertScaleAbs(grad_y, abs_grad_y);

		addWeighted(abs_grad_x, 0.5, abs_grad_y, 0.5, 0, grad);

		QImage image = QImage(grad.data, grad.cols, grad.rows, (int)grad.step, QImage::Format_Grayscale8);
		VscObject::getGui()->getGui()->label_areaEditor->setPixmap(QPixmap::fromImage(image));
	}
	else if ((VscShape::getList()->getSelected() == l_ptAreaLaplace) && (l_ptAreaLaplace != nullptr))
	{
		// LAPLACE
		//
		// -----------------------------------------------
		cv::Mat l_matSrc = l_ptAreaLaplace->getMat()->getDisplayMatWithShape();

		// Declare the variables we are going to use
		cv::Mat src, src_gray, dst;
		int kernel_size = 3;	// PARAMETRE A MODIFIER
		int scale = 1;			// PARAMETRE A MODIFIER
		int delta = 0;			// PARAMETRE A MODIFIER
		int ddepth = CV_16S;

		// Reduce noise by blurring with a Gaussian filter ( kernel size = 3 )
		GaussianBlur(l_matSrc, l_matSrc, cv::Size(3, 3), 0, 0, cv::BORDER_DEFAULT);
		cv::cvtColor(l_matSrc, src_gray, cv::COLOR_BGR2GRAY); // Convert the image to grayscale
		cv::Mat abs_dst;
		Laplacian(src_gray, dst, ddepth, kernel_size, scale, delta, cv::BORDER_DEFAULT);
		// converting back to CV_8U
		convertScaleAbs(dst, abs_dst);

		QImage image = QImage(abs_dst.data, abs_dst.cols, abs_dst.rows, (int)abs_dst.step, QImage::Format_Grayscale8);
		VscObject::getGui()->getGui()->label_areaEditor->setPixmap(QPixmap::fromImage(image));
	}
	else if ((VscShape::getList()->getSelected() == l_ptAreaCanny) && (l_ptAreaCanny != nullptr))
	{
		// CANNY
		//
		// -----------------------------------------------
		cv::Mat l_matSrc = l_ptAreaCanny->getMat()->getDisplayMatWithShape();

		cv::Mat src_gray;
		cv::Mat dst, detected_edges;
		//int lowThreshold = 0;
		int lowThreshold = 50;				 // PARAMETRE A MODIFIER
		const int max_lowThreshold = 100;
		const int ratio = 3;
		const int kernel_size = 3;

		dst.create(l_matSrc.size(), l_matSrc.type());
		cvtColor(l_matSrc, src_gray, cv::COLOR_BGR2GRAY);
		blur(src_gray, detected_edges, cv::Size(3, 3));
		Canny(detected_edges, detected_edges, lowThreshold, lowThreshold*ratio, kernel_size);
		dst = cv::Scalar::all(0);
		l_matSrc.copyTo(dst, detected_edges);

		QImage image = QImage(dst.data, dst.cols, dst.rows, (int)dst.step, QImage::Format_RGB888);
		VscObject::getGui()->getGui()->label_areaEditor->setPixmap(QPixmap::fromImage(image));
	}
#endif

#if 0
	// EXEMPLE 16 : Affichage d'un cercle et d'un texte dans les vues
	// "Edition" et "Aper�u"
	// ------------------------------------------------------------------------
	VscPointRef * l_ptPoint1 = getPointRef("MonPointRef");
	if (nullptr != l_ptPoint1)
	{
		// Exemple d'affichage d'un cercle
		cv::Point center(l_ptPoint1->getX() * p_cvMat->getScale(), l_ptPoint1->getY() * p_cvMat->getScale());
		circle(p_matEditor, center, 50, cv::Scalar(0, 0, 220), 3);
		circle(p_matRun, center, 50, cv::Scalar(0, 0, 220), 3);

		// Exemple d'affichage d'un texte
		putText(p_matEditor, "MonTexte", center + cv::Point(20, 20), cv::FONT_HERSHEY_PLAIN, 0.7, cv::Scalar(0, 0, 255), 1);
		putText(p_matRun, "MonTexte", center + cv::Point(20, 20), cv::FONT_HERSHEY_PLAIN, 0.7, cv::Scalar(0, 0, 255), 1);
	}

	// EXEMPLE 17 : Affichage d'une ligne X=20,Y=20 vers X=40,Y=40 dans les vues
	// "Edition", "Aper�u" et "calibrage" de couleur noir.
	// ------------------------------------------------------------------------
	line(p_matEditor, cv::Point(20,20) * p_cvMat->getScale(), cv::Point(40, 40) * p_cvMat->getScale(), cv::Scalar(0, 0, 0), 3);
	line(p_matRun, cv::Point(20, 20) * p_cvMat->getScale(), cv::Point(40, 40) * p_cvMat->getScale(), cv::Scalar(0, 0, 0), 3);
	line(p_matCalib, cv::Point(20, 20) * p_cvMat->getScale(), cv::Point(40, 40) * p_cvMat->getScale(), cv::Scalar(0, 0, 0), 3);
#endif
}

//
// R�cup�re un pointeur sur une zone. Si l'objet n'existe pas, g�n�ration d'un assert
//
VscArea * VscAlgoLibre::getArea(const char * p_strName)
{
	VscArea * l_ptShape = dynamic_cast <VscArea *>(VscShape::getList()->getItem(p_strName));
	return (l_ptShape);
}

//
// R�cup�re un pointeur sur un axe. Si l'objet n'existe pas, g�n�ration d'un assert
//
VscAxis * VscAlgoLibre::getAxis(const char * p_strName)
{
	VscAxis * l_ptShape = dynamic_cast <VscAxis *>(VscShape::getList()->getItem(p_strName));
	return (l_ptShape);
}

//
// R�cup�re un pointeur sur un point (n'importe lequel). Si l'objet n'existe pas, g�n�ration d'un assert
//
VscPoint * VscAlgoLibre::getPoint(const char * p_strName)
{
	VscAssert(m_bInit == true);
	VscPoint * l_ptShape = dynamic_cast <VscPoint *>(VscShape::getList()->getItem(p_strName));
	return (l_ptShape);
}

//
// R�cup�re un pointeur sur un point de r�f�rence (point fixe). Si l'objet n'existe pas, g�n�ration d'un assert
//
VscPointRef * VscAlgoLibre::getPointRef(const char * p_strName)
{
	VscAssert(m_bInit == true);
	VscPointRef * l_ptShape = dynamic_cast <VscPointRef *>(VscShape::getList()->getItem(p_strName));
	return (l_ptShape);
}

//
// R�cup�re un pointeur sur un point cr�� � partir des outils d'une zone. Si l'objet n'existe pas, g�n�ration d'un assert
//
VscPointArea * VscAlgoLibre::getPointArea(const char * p_strName)
{
	VscAssert(m_bInit == true);
	VscPointArea * l_ptShape = dynamic_cast <VscPointArea *>(VscShape::getList()->getItem(p_strName));
	return (l_ptShape);
}

//
// R�cup�re un pointeur sur un point cr�� � partir d'un autre point. Si l'objet n'existe pas, g�n�ration d'un assert
//
VscPointOfPoint * VscAlgoLibre::getPointChild(const char * p_strName)
{
	VscAssert(m_bInit == true);
	VscPointOfPoint * l_ptShape = dynamic_cast <VscPointOfPoint *>(VscShape::getList()->getItem(p_strName));
	return (l_ptShape);
}

//
// R�cup�re un pointeur sur un point cr�� � partir d'un axe. Si l'objet n'existe pas, g�n�ration d'un assert
//
VscPointOfAxis * VscAlgoLibre::getPointAxis(const char * p_strName)
{
	VscAssert(m_bInit == true);
	VscPointOfAxis * l_ptShape = dynamic_cast <VscPointOfAxis *>(VscShape::getList()->getItem(p_strName));
	return (l_ptShape);
}