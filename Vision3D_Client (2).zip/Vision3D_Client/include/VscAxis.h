///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_AXIS_H
#define VSC_AXIS_H

#include <qstring.h>

#include "VscShape.h"
#include "VscListShape.h"

class VscPointOfAxis;
class VscPoint;
class VscMatZ;

class VscAxis : public VscShape
{
public:
	VscAxis();
	~VscAxis();

	static VscListShape * getList();

	virtual bool load(const rapidjson::Value & p_jsonVal) override;
	virtual void save(rapidjson::Value & p_jsonVal) const override;

	virtual void updateMySelf(VscMatZ * p_cvMatImageZ) override;

	virtual void displayMySelf(VscMatZ * p_cvMat, cv::Mat & p_cvMatToFill, bool p_bIsOptionCoord = true) override;
	virtual void displayViewParameters(bool p_bChangedView) const override;

	virtual const QString & getListDisplay() override;

	VscPoint * getPointBegin() const;
	VscPoint * getPointEnd() const;

	unsigned short getDistanceXY() const;
	unsigned short getDistance() const;
	unsigned short getDistanceMM() const;

private:
	static VscListShape m_list;
};

#endif // VSC_AXIS_H