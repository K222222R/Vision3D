///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_LIST_SHAPE_H
#define VSC_LIST_SHAPE_H

#include <qstring.h>

#include "VscConst.h"
#include "VscList.h"

class VscShape;
class VscMatZ;

class VscListShape : public VscList
{
public:
	VscListShape();
	virtual ~VscListShape();

	VscShape * getItem(int p_iIndex) const;
	VscShape * getItem(const QString & p_strName) const;

	void init();
	void updateStart();
	void updateInProgress(VscMatZ * p_cvMat);
	void updateStop();

	void removeShape(const VscShape * p_ptShape);

	VscShape * getSelected();

	void removeAll();
};

#endif // VSC_LIST_SHAPE_H
