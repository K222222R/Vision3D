///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_AREA_H
#define VSC_AREA_H

#include <qstring.h>

#include "VscShape.h"
#include "VscMatZ.h"
#include "VscListShape.h"
#include "VscList.h"

#include <rapidjson/document.h>


class VscArea : public VscShape
{
public:
	VscArea();
	~VscArea();

	static VscListShape * getList();

	virtual bool load(const rapidjson::Value & p_jsonVal) override;
	virtual void save(rapidjson::Value & p_jsonVal) const override;

	virtual void updateMySelf(VscMatZ * p_cvMatImageZ) override;

	virtual void displayMySelf(VscMatZ * p_cvMat, cv::Mat & p_cvMatToFill, bool p_bIsOptionCoord = true) override;
	virtual void displayViewParameters(bool p_bChangedView) const override;


	// Size
	// ------------------------------------------------------------------------------------
	void setSize(int p_iWidth, int p_iHeight);
	void getParamSize(int & p_tWidth, int & p_tHeight) const;
	void getSize(int & p_iWidth, int & p_iHeight) const;
	// ------------------------------------------------------------------------------------


	// Recalage
	// ------------------------------------------------------------------------------------
	void setPointOrigin(int p_usX, int p_usY);
	void getPointOrigin(int & p_tX, int & p_tY) const;
	const cv::Point & getNewOriginSize() const;
	// ------------------------------------------------------------------------------------
	
	void setMinAuto();
	void setMinAbsolute(int p_iMin);
	void setMinOffset(int p_iMin);

	void setMaxAuto();
	void setMaxAbsolute(int p_iMax);
	void setMaxOffset(int p_iMax);

	void getParamMinMaxZ(int & p_tMinZ, int & p_tMaxZ) const;
	void getMinMaxZ(short & valeur_min, short & valeur_max) const;
	void getParamModeZ(bool & p_bMinAuto, bool & p_bMinAbs, bool & p_bMinOfs, bool & p_bMaxAuto, bool & p_bMaxAbs, bool & p_bMaxOfs) const;


	const cv::Point & getStartPoint() const;
	VscMatZ * getMat();
	const VscMatZ * getMat() const;

	
	//virtual void updateChild(VscMatZ * p_cvMat);

	void updateNewOrigin(VscMatZ * p_cvMatImageZ);
	void updateSize(VscMatZ * p_cvMatImageZ);
	void updateArea(VscMatZ * p_cvMatImageZ);
	void updateAreaPoint(VscMatZ * p_cvMatImageZ);
	
	//virtual void getSubParent(VscShape ** p_ppShape, unsigned short p_usNbMax) const;

private:
	static VscListShape m_list;

	int m_tParamSizeWidth;
	int m_tParamSizeHeight;
	int m_tParamRangeMinZ;
	int m_tParamRangeMaxZ;

	int m_tParamNewOriginX;
	int m_tParamNewOriginY;

	bool m_bMinAuto;
	bool m_bMinAbs;
	bool m_bMinOfs;
	bool m_bMaxAuto;
	bool m_bMaxAbs;
	bool m_bMaxOfs;
	
	cv::Point m_ptsOrigin;
	cv::Point m_ptsOriginDelta;
	cv::Point m_ptsStartArea;


	cv::Size m_size;

	VscMatZ m_matAreaZ;

};

#endif // VSC_AREA_H

