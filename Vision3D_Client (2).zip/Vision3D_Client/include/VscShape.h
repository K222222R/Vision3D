///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_SHAPE_H
#define VSC_SHAPE_H

#include <qstring.h>
#include <qmutex.h>
#include <qlistwidget.h>

#include <rapidjson/document.h>

#include"VscObject.h"

#include "VscListShape.h"

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>


class VscMatZ;

class VscShape : public VscObject
{
public:
	VscShape();
	virtual ~VscShape() = 0;

	static VscListShape * getList();

	virtual bool load(const rapidjson::Value & p_jsonVal);
	virtual void save(rapidjson::Value & p_jsonVal) const;

	void setPreview(bool p_bIsPreview);
	bool isPreview() const;

	void setExported(bool p_bIsExported);
	bool isExported() const;

	void setChecked(bool p_bCheck);
	bool isChecked() const;

	bool setName(const QString & p_strName);
	const QString & getName() const;
	const char * getNameChar() const;
	static bool checkName(const QString & p_strName);

	typedef void(*TClbkExternalBefore) (VscShape *, VscMatZ *);
	typedef bool(*TClbkExternalAfter) (VscShape *, VscMatZ *);
	void setExternal(TClbkExternalBefore p_tClbkExternalBefore, TClbkExternalAfter p_tClbkExternalAfter = nullptr);
	void setInternal();
	bool isExternal() const;

	typedef enum
	{
		VSC_SHAPE_STATE_NOT_UPDATED = 0x00,
		VSC_SHAPE_STATE_UPDATE_IN_PORGRESS,
		VSC_SHAPE_STATE_UPDATE_OK,
		VSC_SHAPE_STATE_UPDATE_NOK
	} TState;
	TState getState() const;

	virtual const QString & getListDisplay();
	//QListWidgetItem * getWidgetList();

	

	bool isSelected();


	
	VscShape * getChild(const QString & p_strName) const;
	const VscListShape * getListChild() const;
	VscListShape * getListChild();
	VscListShape * getListChildInternal();

	void setParent(VscShape * p_ptParent);
	VscShape * getParent(int p_iIndex = 0) const;
	void addParent(VscShape * p_ptShape, bool p_bInternal = false);
	VscShape * getParent(const QString & p_strName) const;
	const VscListShape * getListParent() const;
	VscListShape * getListParent();
	VscListShape * getListParentInternal();

	virtual void init();
	void updateStart();
	void updateInProgress(VscMatZ * p_cvMat);
	void updateStop();

	//virtual void updateSubParent(VscMatZ * p_cvMat) = 0;
	
	

	virtual void displayMySelf(VscMatZ * p_cvMat, cv::Mat & p_cvMatToFill, bool p_bIsOptionCoord = true) = 0;
	virtual void displayViewParameters(bool p_bChangedView) const;


	bool checkChildAndParent(); // const;
	bool checkChild(const VscShape * l_ptShape) const;
	bool checkParent(const VscShape * l_ptShape) const;

	bool isUpdated() const;

	void setErrorIgnored(bool p_bIsErrorIgnored);
	bool isErrorIgnored() const;

	void setOk();
	bool isOk() const;

	void setNok();
	bool isNok() const;

	void setData(void * p_pvData);
	void * getData() const;


	void remove();

protected :
	

	void addChild(VscShape * p_ptShape, bool p_bInternal);

	virtual void updateMySelf(VscMatZ * p_cvMat) = 0;
	void updateParent(VscMatZ * p_cvMat);
	void updateChild(VscMatZ * p_cvMat);


	QString m_strListDisplay;

	

private:

	static VscListShape m_list;

	

	VscListShape m_listChild;
	VscListShape m_listParent;

	VscListShape m_listChildInternal;
	VscListShape m_listParentInternal;

	//void updateParent(VscMatZ * p_cvMat);

	bool m_bIsErrorIgnored;
	bool m_bIsPreview;
	bool m_bIsExported;
	bool m_bIsChecked;
	//bool m_bIsExternal;

	TState m_tState;
	TClbkExternalBefore m_tClbkExternalBefore;
	TClbkExternalAfter m_tClbkExternalAfter;


	//bool m_bIsFree;
	QString m_strName;
	

	//VscShape * m_ptParent;

	QMutex m_tUpdateInProgress;


	void * m_pvData;

	//QListWidgetItem m_widgetItem;
};

#endif // VSC_SHAPE_H

