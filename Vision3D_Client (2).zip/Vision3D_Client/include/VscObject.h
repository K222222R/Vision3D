///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_OBJECT_H
#define VSC_OBJECT_H

#include "VscList.h"

#include <qstring.h>
#include <qmutex.h>
#include <rapidjson/document.h>

class VscConfigFile;
class Vision3D;

class VscObject
{
public:
	VscObject();
	virtual ~VscObject() = 0;

	static void setConfig(VscConfigFile * p_ptConfig);
	static VscConfigFile * getConfig();

	int getId() const;
	
	virtual bool load(const rapidjson::Value & p_jsonVal) = 0;
	virtual void save(rapidjson::Value & p_jsonVal) const = 0;

	void setFree(bool p_bIsFree);
	bool isFree() const;

	void setEnabled(bool p_bIsEnabled);
	bool isEnabled() const;

	static VscList * getList();

	static void setGui(Vision3D * m_ptVision);
	static Vision3D *getGui();

protected:
	static VscConfigFile * m_ptConfig;
	static Vision3D * m_ptVision;

private:
	static int m_iGlobalId;
	
	int m_id;
	
	bool m_bIsFree;
	bool m_bIsEnabled;

	static VscList m_list;
};

#endif // VSC_OBJECT_H

