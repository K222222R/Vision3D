///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_ALGO_LIBRE_H
#define VSC_ALGO_LIBRE_H

#include "VscListShape.h"
#include "VscMatZ.h"

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

class VscArea;
class VscAxis;
class VscPoint;
class VscPointRef;
class VscPointArea;
class VscPointOfPoint;
class VscPointOfAxis;
class VscItfExterneModbus;

class VscAlgoLibre
{
public:
	VscAlgoLibre();
	~VscAlgoLibre();

	//
	// Appel� une seule fois au demarrage apr�s le chargement du fichier de configuration
	// ATTENTION : � ne pas effacer des informations pr�sentes dans le fichier de configuration
	//
	void init();
	static void update_pCloiaque(VscShape* p_ptShape, VscMatZ* p_cvMatImageZ);
	static void update_pFm_before(VscShape* p_ptShape, VscMatZ* p_cvMatImageZ);
	static bool update_pFm_after(VscShape* p_ptShape, VscMatZ* p_cvMatImageZ);
	static void update_pFm_before2(VscShape* p_ptShape, VscMatZ* p_cvMatImageZ);
	static bool update_pFm_after2(VscShape* p_ptShape, VscMatZ* p_cvMatImageZ);
	


	//
	// Appel� apr�s chaque mise � jour d'une image
	//
	void updateShapeCompleted(VscMatZ * p_cvMat);

	//
	// Appel� lors de la mise � jour les registres du modbus
	//
	void recvFromModbus(VscItfExterneModbus * p_ptModbus);

	//
	// Appel� pour mettre � jour les registres du modbus
	//
	void SendToModbus(VscItfExterneModbus * p_ptModbus);

	//
	// Appel� pour faire un affichage sp�cifique
	//
	void specialDisplay(VscMatZ * p_cvMat, cv::Mat & p_matRun, cv::Mat & p_matEditor, cv::Mat & p_matCalib);

private:
	bool m_bInit;

	static int CAA, CAD, CBA, CBD;
	static int CCP1D, CDA, CDP1D;

	//
	// R�cup�re un pointeur sur une zone. Si l'objet n'existe pas, g�n�ration d'un assert
	//
	VscArea * getArea(const char * p_strName);

	//
	// R�cup�re un pointeur sur un axe. Si l'objet n'existe pas, g�n�ration d'un assert
	//
	VscAxis * getAxis(const char * p_strName);

	//
	// R�cup�re un pointeur sur un point (n'importe lequel). Si l'objet n'existe pas, g�n�ration d'un assert
	//
	VscPoint * getPoint(const char * p_strName);

	//
	// R�cup�re un pointeur sur un point de r�f�rence (point fixe). Si l'objet n'existe pas, g�n�ration d'un assert
	//
	VscPointRef * getPointRef(const char * p_strName);

	//
	// R�cup�re un pointeur sur un point cr�� � partir des outils d'une zone. Si l'objet n'existe pas, g�n�ration d'un assert
	//
	VscPointArea * getPointArea(const char * p_strName);

	//
	// R�cup�re un pointeur sur un point cr�� � partir d'un autre point. Si l'objet n'existe pas, g�n�ration d'un assert
	//
	VscPointOfPoint * getPointChild(const char * p_strName);

	//
	// R�cup�re un pointeur sur un point cr�� � partir d'un axe. Si l'objet n'existe pas, g�n�ration d'un assert
	//
	VscPointOfAxis * getPointAxis(const char * p_strName);
};

#endif // VSC_ALGO_LIBRE_H