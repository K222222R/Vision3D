///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_POINT_H
#define VSC_POINT_H

#include <qpoint.h>
#include <qstring.h>

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

//#include <rapidjson/document.h>

#include "VscArea.h"
#include "VscMatZ.h"
#include "VscShape.h"
#include "VscListShape.h"
#include "VscAxis.h"

class VscArea;
class VscPointOfPoint;

class VscPoint : public VscShape
{
public:
	VscPoint();
	~VscPoint();

	static VscListShape * getList();

	void setCalib(bool p_bCalibX, bool p_bCalibY, bool p_bCalibZ);
	void setNbPointZ(int p_iNbZ);
	void setReference(bool p_bRef);

	//void setParams(bool p_bRef, bool p_bCalibX, bool p_bCalibY, bool p_bCalibZ, int p_iNbZ);

	virtual bool load(const rapidjson::Value & p_jsonVal) override;
	virtual void save(rapidjson::Value & p_jsonVal) const override;// , rapidjson::Document & p_jsonDom);

	
	virtual void displayViewParameters(bool p_bChangedView) const override;


	void setRealCoord(VscPoint * p_ptPoint = nullptr);
	
	//virtual void updateSubParent(VscMatZ * p_cvMat);
	virtual void init() override;
	virtual void updateMySelf(VscMatZ * p_cvMat) override;
	virtual void displayMySelf(VscMatZ * p_cvMat, cv::Mat & p_cvMatToFill, bool p_bIsOptionCoord = true) override;


	void calcValue(VscMatZ * p_cvMat);

	void correction(const cv::Point & p_cvPts, bool p_bEnabled = true);

	unsigned int getNbZ() const;
	
	int getX_MM() const;
	int getY_MM() const;
	int getZ_MM() const;
	int getX() const;
	int getY() const;
	int getZ() const;
	const cv::Point & getPoint() const;

	
	bool isCalib() const;
	bool isCalibX() const;
	bool isCalibY() const;
	bool isCalibZ() const;
	bool isReference() const;
	

	virtual const QString & getListDisplay() override;

	static void setConvDistance(double p_dDistanceX, double p_dDistanceY);

	static void getConvDistance(double & p_dDistanceX, double & p_dDistanceY);

protected:
	static VscListShape m_list;

	cv::Point m_cvPtsOrigin;
	cv::Point m_cvPtsFinal;
	cv::Point m_cvPtsCorrection;
	short m_sValuePtsFinal;

	cv::Point m_cvPtsFinalMM;

	bool m_bIsCorrection;
	
	bool m_bIsRef;
	bool m_bIsCalibX;
	bool m_bIsCalibY;
	bool m_bIsCalibZ;
	unsigned int m_iNbZ;

	static double m_dDistanceX;
	static double m_dDistanceY;

};

#endif // VSC_POINT_H

