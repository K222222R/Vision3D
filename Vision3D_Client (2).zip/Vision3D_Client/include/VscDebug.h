///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_DEBUG_H
#define VSC_DEBUG_H

#include <qfile.h>
#include <qmutex.h>

#include <string.h>

#include <rapidjson/document.h>

//#include "VscConfigFile.h"

#define __FILENAME__ (strrchr(__FILE__, '\\') ? strrchr(__FILE__, '\\') + 1 : __FILE__)

#define VscDebug(Message, ...)		VscDebug::Trace(VscDebug::VSC_TRACE_DEBUG,		__FILENAME__, __LINE__, Message, ##__VA_ARGS__)
#define VscInfo(Message, ...)		VscDebug::Trace(VscDebug::VSC_TRACE_INFO,		__FILENAME__, __LINE__, Message, ##__VA_ARGS__)
#define VscWarning(Message, ...)	VscDebug::Trace(VscDebug::VSC_TRACE_WARNING,	__FILENAME__, __LINE__, Message, ##__VA_ARGS__)
#define VscError(Message, ...)		VscDebug::Trace(VscDebug::VSC_TRACE_ERROR,		__FILENAME__, __LINE__, Message, ##__VA_ARGS__)

#ifdef NDEBUG
#define VscAssert(condi)				VscDebug::Assert(__FILENAME__, __LINE__, condi)	// En release, l'assert, journalise la trace et reboot
#else
#define VscAssert(condi)				assert(condi)	// En debug l'assert correspond � la fonction de base de windows
#endif

#define VSC_SIZE_MAX_BUFFER_TRACE	1024

class VscDebug
{
public:

	typedef enum {
		VSC_TRACE_DEBUG = 0x00,
		VSC_TRACE_INFO,
		VSC_TRACE_WARNING,
		VSC_TRACE_ERROR
	} TTraceType;

	static void Init();
	static void Exit();

	static bool load(const rapidjson::Value & p_jsonVal);
	static void save(rapidjson::Value & p_jsonVal);

	static void Trace(TTraceType p_tType, const char * p_pcFile, int p_iLine, const char * p_pcMessage, ...);
	static void Assert(const char * p_pcFile, int p_iLine, bool l_bCondition);

	static void setGui();

	static bool isEnable();

private:
	static char m_acBufferTrace1[VSC_SIZE_MAX_BUFFER_TRACE];
	static char m_acBufferTrace2[VSC_SIZE_MAX_BUFFER_TRACE];
	static QFile m_fileTrace;
	static bool m_isDebug;

	static QMutex m_tMutex;

};

#endif // VSC_DEBUG_H