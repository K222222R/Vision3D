///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_MAT_Z_H
#define VSC_MAT_Z_H

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/stitching.hpp>

#include <qpoint.h>

#include "VscMat.h"
#include "VscConst.h"



class VscMatZ : public VscMat
{
public:
	VscMatZ();
	~VscMatZ();

	void setMask(short p_sValueMin, short p_sValueMax);

	short getAverageZ(const cv::Point & p_pts, unsigned int p_uiAverage) const;
	
	bool getRealCoord(const QPoint & p_tPoint, cv::Point & p_tNewPoint);
	short getZ(const cv::Point & p_tPoint);

	bool getRowMinX(int y, int & p_iMinX, bool p_bInversed = false) const;
	void getAverageMinX(cv::Point & p_pts, int p_iNbPointAverage, bool p_bInversed = false) const;
	void getMinX(cv::Point & p_pts, int p_iNbPointAverage, bool p_bInversed = false) const;

	bool getRowMaxX(int y, int & p_iMaxX, bool p_bInversed = false) const;
	void getAverageMaxX(cv::Point & p_pts, int p_iNbPointAverage, bool p_bInversed = false) const;
	void getMaxX(cv::Point & p_pts, int p_iNbPointAverage, bool p_bInversed = false) const;

	bool getRowMinY(int y, int & p_iMinY, bool p_bInversed = false) const;
	void getAverageMinY(cv::Point & p_pts, int p_iNbPointAverage, bool p_bInversed = false) const;
	void getMinY(cv::Point & p_pts, int p_iNbPointAverage, bool p_bInversed = false) const;

	bool getRowMaxY(int y, int & p_iMaxY, bool p_bInversed = false) const;
	void getAverageMaxY(cv::Point & p_pts, int p_iNbPointAverage, bool p_bInversed = false) const;
	void getMaxY(cv::Point & p_pts, int p_iNbPointAverage, bool p_bInversed = false) const;

	void getMinZ(cv::Point & p_pts) const;
	void getMaxZ(cv::Point & p_pts) const;

	void rotate(double angle);

	void getMinMaxZ(short & p_sValueMin, short & p_sValueMax) const;


	cv::Point getOffsetFixed(const cv::Point & p_pcvPointOrigin, int p_iDistance, double p_iWay);

	cv::Point getOffsetHighFrontWay(const cv::Point & p_pcvPointOrigin, int p_iDistance, int p_iWayHeight, int p_iWayWidth, int p_iWayOcc, int p_iWayOffset);
	cv::Point getOffsetLowFrontWay(const cv::Point & p_pcvPointOrigin, int p_iDistance, int p_iWayHeight, int p_iWayWidth, int p_iWayOcc, int p_iWayOffset, unsigned int p_uiSeuilTapis);
	cv::Point getOffsetHighLowFrontWay(const cv::Point & p_pcvPointOrigin, int p_iDistance, int p_iWayHeight, int p_iWayWidth, int p_iWayOcc, int p_iWayOffset);
	cv::Point getDirectionOffsetRangeZ(const cv::Point & p_pcvPointOrigin, int p_iDistance, int p_iZMin, int p_iZMax, int p_iWayOffset);

	cv::Point getOffsetHighFrontDistance(const cv::Point & p_pcvPointOrigin, int p_iWay, int p_iDistanceHeight, int p_iDistanceWidth, int p_iDistanceOcc);
	cv::Point getOffsetLowFrontDistance(const cv::Point & p_pcvPointOrigin, int p_iWay, int p_iDistanceHeight, int p_iDistanceWidth, int p_iDistanceOcc, unsigned int p_uiSeuilTapis);
	cv::Point getOffsetHighLowFrontDistance(const cv::Point & p_pcvPointOrigin, int p_iWay, int p_iDistanceHeight, int p_iDistanceWidth, int p_iDistanceOcc);
	cv::Point getDistanceOffsetRangeZ(const cv::Point & p_pcvPointOrigin, int p_iWay, int p_iZMin, int p_iZMax);

	
	cv::Mat1s & getMat();
	cv::Mat1s & getMat() const;
	const cv::Mat & getDisplayMat() const;
	cv::Mat & getDisplayMat();
	cv::Mat & getDisplayMatWithShape();
	const cv::Mat & getDisplayMatWithShape() const;

	void addShape();

	void createDisplayMat(cv::Mat & p_matOut);
	void createDisplayMat(const cv::Mat1s & p_matIn, cv::Mat & p_matOut, double p_dScale);

	virtual void stitcher();
	void stitcherPortrait();
	void stitcherLandscape();


	void setColorAuto(bool p_bIsAuto, int p_iMin, int p_iMax);
	bool isColorAuto() const;
	int getColorMin() const;
	int getColorMax() const;
	
private :
	
	cv::Mat m_cvMatToDisplay;
	cv::Mat m_cvMatToDisplayWithShape;

	cv::Mat m_cvMatToDisplayMask;

	bool m_bIsColorAuto;
	int m_iColorMin;
	int m_iColorMax;
};

#endif // VSC_MAT_Z_H

