///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_POINT_OF_AXIS_H
#define VSC_POINT_OF_AXIS_H

#include "VscPointChildren.h"
#include "VscList.h"
#include "VscMatZ.h"

class VscPointOfAxis : public VscPointOfPoint
{
public:
	VscPointOfAxis();
	virtual ~VscPointOfAxis();

	static VscList * getList();

	virtual bool load(const rapidjson::Value & p_jsonVal) override;
	virtual void save(rapidjson::Value & p_jsonVal) const override;

	virtual void updateMySelf(VscMatZ * p_cvMat) override;

	virtual void displayViewParameters(bool p_bChangedView) const override;

	void setFirstPoint(bool p_bStartPoint);
	void setDistanceFixedPercent(int p_iFixedPercent);
	void setDistanceFixedValue(int p_iFixedPercent);

private:
	static VscList m_list;

	bool m_bStartPointIsFirstPoint;
	bool m_bIsPercent;
	int m_iDistanceFixedPercent;
};

#endif // VSC_POINT_OF_AXIS_H

