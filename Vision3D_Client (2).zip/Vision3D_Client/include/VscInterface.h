///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_INTERFACE_H
#define VSC_INTERFACE_H

#include "VscList.h"
#include "VscObject.h"
#include <qfuture.h>

#include <rapidjson/document.h>


class VscImage;

class VscInterface : public VscObject
{
public:
	VscInterface();
	virtual ~VscInterface() = 0;

	void setImage(VscImage * p_ptImage);

	virtual bool load(const rapidjson::Value & p_jsonVal);
	virtual void save(rapidjson::Value & p_jsonVal) const;
	virtual void update() = 0;

	VscImage * getImage();

	bool isRunning() const;
	bool isSelected() const;
	bool isThreadRunning();

	
	virtual void stop();
	void select(bool p_bIsSelected);
	virtual bool open() = 0;
	virtual void close() = 0;
	void * read();
	virtual void write();

	static VscList * getList();

	bool start();

protected:
	VscImage * m_ptImage;
	bool m_bIsRunning;
	bool m_bIsSelected;
	bool m_bIsThreadRunning;
	QFuture<void> f;

private:
	void run();

	
	static VscList m_listItf;


	
};

#endif // VSC_INTERFACE_H
