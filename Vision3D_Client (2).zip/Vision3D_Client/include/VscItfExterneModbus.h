///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

// SPEC: http://www.modbus.org/docs/Modbus_Application_Protocol_V1_1b.pdf

#ifndef VSC_ITF_EXTERNE_MODBUS_H
#define VSC_ITF_EXTERNE_MODBUS_H

#include "VscInterface.h"

#include <qtcpsocket.h>
#include <qtcpserver.h>
#include <qmutex.h>
#include <rapidjson/document.h>
#include "VscConst.h"



#define VSC_NB_MAX_MODBUS_BUFFER_SIZE	512


#define PACKED
#pragma pack(push,1)
struct VscModbus
{
	struct {
		unsigned char ucUnusedData[4];
		unsigned short usSizeTrame;
		unsigned char ucSlaveId;
		unsigned char ucFunctionCode;
	} header;

	union {

		struct {
			unsigned short usStartingAddress;
			unsigned short usQuantity;
		} ReadMultipleRegistersRequest;

		struct {
			unsigned char ucByteCount;
			unsigned short ausRegisters[VSC_NB_MAX_MODBUS_REGISTER];
		} ReadMultipleRegistersResponse;

		struct {
			unsigned short usStartingAddress;
			unsigned short usQuantity;
			unsigned char ucByteCount;
			unsigned short ausRegisters[VSC_NB_MAX_MODBUS_REGISTER];
		} WriteMultipleRegistersRequest;

		struct {
			unsigned short usStartingAddress;
			unsigned short usQuantity;
		} WriteMultipleRegistersResponse;

		struct {
			unsigned short usReadStartingAddress;
			unsigned short usQuantityToRead;
			unsigned short usWriteStartingAddress;
			unsigned short usQuantityToWrite;
			unsigned char ucWriteByteCount;
			unsigned short ausRegisters[VSC_NB_MAX_MODBUS_REGISTER];
		} ReadWriteMultipleRegistersRequest;

		struct {
			unsigned char ucByteCount;
			unsigned short ausRegisters[VSC_NB_MAX_MODBUS_REGISTER];
		} ReadWriteMultipleRegistersResponse;
	};

} PACKED;
#pragma pack(pop)
#undef PACKED


class VscShape;

class VscItfExterneModbus : public VscInterface
{
public:
	// Constructor and destructor
	VscItfExterneModbus();
	virtual ~VscItfExterneModbus();

	bool open();
	void close();

	virtual bool load(const rapidjson::Value & p_jsonVal);
	virtual void save(rapidjson::Value & p_jsonVal) const;

	virtual void stop();
	virtual void update();	

	void updateMaster();
	void updateSlave();

	bool send(unsigned short p_usAddress = 0x0000, unsigned short p_usNbRegister = VSC_NB_MAX_MODBUS_REGISTER);
	bool sendToModbusSlave(unsigned short p_usAddress, unsigned short p_usNbRegister);

	bool recv(unsigned short p_usAddress = 0x0000, unsigned short p_usNbRegister = VSC_NB_MAX_MODBUS_REGISTER);
	bool recvFromModbusSlave(unsigned short p_usAddress, unsigned short p_usNbRegister);

	// Set member function
	void setMaster(bool p_bIsMaster);
	void setIP(const QString & p_strIP);
	void setServer(const QString & p_strServername);
	void setPort(unsigned short p_usPort);
	void setSlaveId(int id);
	void setRegister(unsigned short p_usAddress, unsigned short p_usValue);
	void setValue(unsigned short p_usAddress, int p_usValue);
	void setXYZ(unsigned short p_usAddress, int p_iX, int p_iY, int p_iZ);
	void setShape(unsigned short p_usAddress, const VscShape * p_ptShape);

	// Get member function
	const QString & getAddressIP() const;
	unsigned short getPort() const;
	int getSlaveId() const;
	unsigned short getRegister(unsigned short p_usAddress) const;
	unsigned short getValue(unsigned short p_usAddress) const;
	void getXYZ(unsigned short p_usAddress, int & p_iX, int & p_iY, int & p_iZ) const;


	bool isMaster() const;

	unsigned short toLittleBig(unsigned short p_usData);

	void sendResponse(unsigned short l_usSize);

private:

	///Function Code
	// Modbus function codes
	enum {
		/*
		READ_COILS		= 0x01,
		READ_INPUT_BITS = 0x02,
		READ_REGS		= 0x03,
		READ_INPUT_REGS = 0x04,
		WRITE_COIL		= 0x05,
		WRITE_REG		= 0x06,
		WRITE_COILS		= 0x0F,
		WRITE_REGS		= 0x10,*/

		MODBUS_FUNCTION_CODE_READ_DISCRETE_INPUTS				= 2,
		MODBUS_FUNCTION_CODE_READ_COILS							= 1,
		MODBUS_FUNCTION_CODE_WRITE_SINGLE_COIL					= 5,
		MODBUS_FUNCTION_CODE_WRITE_MULTIPLE_COILS				= 15,
		MODBUS_FUNCTION_CODE_READ_INPUT_REGISTERS				= 4,
		MODBUS_FUNCTION_CODE_READ_MULTIPLE_HOLDING_REGISTERS	= 3,
		MODBUS_FUNCTION_CODE_WRITE_SINGLE_HOLDING_REGISTERS		= 6,
		MODBUS_FUNCTION_CODE_WRITE_MULTIPLE_HOLDING_REGISTERS	= 16,
		MODBUS_FUNCTION_CODE_READ_WRITE_MULTIPLE_REGISTERS		= 23,
		MODBUS_FUNCTION_CODE_MASK_WRITE_REGISTER				= 22,
		MODBUS_FUNCTION_CODE_READ_FIFO_QUEUE					= 24,
		MODBUS_FUNCTION_CODE_READ_FILE_RECORD					= 20,
		MODBUS_FUNCTION_CODE_WRITE_FILE_RECORD					= 21,
		MODBUS_FUNCTION_CODE_READ_EXCEPTION_STATUS				= 7,
		MODBUS_FUNCTION_CODE_DIAGNOSTIC							= 8,
		MODBUS_FUNCTION_CODE_GET_COM_EVENT_COUNTER				= 11,
		MODBUS_FUNCTION_CODE_GET_COM_EVENT_LOG					= 12,
		MODBUS_FUNCTION_CODE_REPORT_SLAVE_ID					= 17,
		MODBUS_FUNCTION_CODE_READ_DEVICE_IDENTIFICATION			= 43,
		MODBUS_FUNCTION_CODE_ENCAPSULATED_INTERFACE_TRANSPORT	= 43
	};

	VscModbus m_sRequest;
	VscModbus m_sResponse;

	bool m_bIsMaster;
	QString m_strServername;
	QString m_strIP;
	unsigned short m_usPort;
	int m_iSlaveid;
	QTcpServer m_server;
	QTcpSocket m_tcpMaster;
	QTcpSocket m_tcpMasterOpen;
	unsigned short m_usRegisters[VSC_NB_MAX_MODBUS_REGISTER];
	unsigned char m_ucBufferToSend[VSC_NB_MAX_MODBUS_BUFFER_SIZE];
	QMutex m_mutex;

	QTcpSocket *m_socketClient;
};

#endif // VSC_ITF_EXTERNE_MODBUS_H

