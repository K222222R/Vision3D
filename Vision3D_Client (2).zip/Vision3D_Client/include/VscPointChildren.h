///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_POINT_CHILDREN_H
#define VSC_POINT_CHILDREN_H

#include "VscPoint.h"
#include "VscList.h"

class VscPointOfPoint : public VscPoint
{
public:
	VscPointOfPoint();
	virtual ~VscPointOfPoint();

	static VscList * getList();

	virtual bool load(const rapidjson::Value & p_jsonVal) override;
	virtual void save(rapidjson::Value & p_jsonVal) const override;

	virtual void updateMySelf(VscMatZ * p_cvMat) override;

	virtual void displayViewParameters(bool p_bChangedView) const override;

	typedef enum {
		VSC_POINT_OF_POINT_FIXE = 0x00,
		VSC_POINT_OF_POINT_HIGH_FRONT,
		VSC_POINT_OF_POINT_LOW_FRONT,
		VSC_POINT_OF_POINT_HIGH_LOW_FRONT,
		VSC_POINT_OF_POINT_RANGE_Z
	} TPointOfPointType;

	void setDistanceFixedValue(int p_iFixedValue);
	void setDistanceFrontHigh(int p_iHeight, int p_iWidth, int p_iNbOcc);
	void setDistanceFrontLow(int p_iHeight, int p_iWidth, int p_iNbOcc);
	void setDistanceFrontHighOrLow(int p_iHeight, int p_iWidth, int p_iNbOcc);
	void setDistanceRangeZ(int p_iZMin, int p_iZMax);

	int getDistanceFixedValueOrigin() const;
	int getDistanceFixedValue() const;
	int getDistanceFrontHeight() const;
	int getDistanceFrontWidth() const;
	int getDistanceFrontOcc() const;
	int getDistanceRangeZMin() const;
	int getDistanceRangeZMax() const;

	bool isDistanceFixedValue() const;
	bool isDistanceFrontHigh() const;
	bool isDistanceFrontLow() const;
	bool isDistanceFrontHighOrLow() const;
	bool isDistanceRangeZ() const;

	void setDirectionFixedValue(double p_dFixedValue);
	void setDirectionFrontHigh(int p_iHeight, int p_iWidth, int p_iNbOcc);
	void setDirectionFrontLow(int p_iHeight, int p_iWidth, int p_iNbOcc);
	void setDirectionFrontHighOrLow(int p_iHeight, int p_iWidth, int p_iNbOcc);
	void setDirectionRangeZ(int p_iZMin, int p_iZMax);

	double getDirectionFixedValue() const;
	int getDirectionFrontHeight() const;
	int getDirectionFrontWidth() const;
	int getDirectionFrontOcc() const;
	int getDirectionRangeZMin() const;
	int getDirectionRangeZMax() const;

	bool isDirectionFixedValue() const;
	bool isDirectionFrontHigh() const;
	bool isDirectionFrontLow() const;
	bool isDirectionFrontHighOrLow() const;
	bool isDirectionRangeZ() const;

private:
	static VscList m_list;

protected:

	cv::Point getOffset(VscMatZ * p_cvMat, const cv::Point & p_pcvPointOrigin, double p_dWayOffset = 0);

	TPointOfPointType m_eDistanceType;
	int m_iDistanceFixedValueOrigin;
	int m_iDistanceFixedValue;
	int m_iDistanceFrontHeight;
	int m_iDistanceFrontWidth;
	int m_iDistanceFrontOcc;
	int m_iDistanceRangeZMin;
	int m_iDistanceRangeZMax;

	TPointOfPointType m_eDirectionType;
	double m_dDirectionFixedValue;
	int m_iDirectionFrontHeight;
	int m_iDirectionFrontWidth;
	int m_iDirectionFrontOcc;
	int m_iDirectionRangeZMin;
	int m_iDirectionRangeZMax;

	cv::Point m_cvPts;
};

#endif // VSC_POINT_CHILDREN_H

