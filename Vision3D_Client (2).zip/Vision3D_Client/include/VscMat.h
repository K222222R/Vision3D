///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_MAT_H
#define VSC_MAT_H

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/stitching.hpp>

#include "VscConst.h"

class VscMat
{
public:
	VscMat();
	virtual ~VscMat() = 0;

	bool isReady() const;
	bool isEmpty() const;
	bool isInMat(const cv::Point & p_tPoint) const;
	bool isEmptySub() const;

	void forceInMat(cv::Point & p_tPoint);

	void upScale();
	void downScale();
	void setScale(double p_dScale);
	double getScale();

	cv::Mat & getMat();
	cv::Mat & getMat() const;

	unsigned int write(cv::Mat & p_cvMatImage);
	void update();	

	void trimSubImage(int p_iCurrentIndex);
	void rotateSubImage(int p_iCurrentIndex);
	void trimImage();
	void rotateImage();
	void concat();

	void resetCurrentSubImage();
	void setParamNbSubImage(unsigned short p_usNbSubImage);
	unsigned short getParamNbSubImage() const;

	void setParamOption(bool p_bLandscape);
	bool isLandscape() const;

	void setParamAutoPastle(bool p_bAutoPaste, int p_iX, int p_iY, int p_iHeight, int p_iWidth, int p_iTheshold);
	bool isAutoPastle() const;
	const cv::Rect & getAreaAutoPastle() const;
	int getPastleTheshold() const;

	void setParamSubRotate(int p_iIndex, unsigned short p_usSubRotate);
	unsigned short getParamSubRotate(int p_iIndex) const;

	void setParamSubTrim(int p_iIndex, int p_iTop, int p_iBottom, int p_iLeft, int p_iRight);
	void getParamSubTrim(int p_iIndex, int & p_iTop, int & p_iBottom, int & p_iLeft, int & p_iRight) const;

	void setParamTrim(int p_iTop, int p_iBottom, int p_iLeft, int p_iRight);
	void getParamTrim(int & p_iTop, int & p_iBottom, int & p_iLeft, int & p_iRight) const;

	void setParamRotate(unsigned short p_usRotate);	
	unsigned short getParamRotate() const;


	const cv::Mat & getMatSubImage(unsigned int p_uiIndex) const;
	cv::Mat & getMatSubImage(unsigned int p_uiIndex);

private:

	

	int getSubImageMinRows() const;
	int getSubImageMinCols() const;

	void autoTrimSubImageRows();
	void autoTrimSubImageCols();

	virtual void stitcher();
	
	cv::Mat m_cvMatSubImageOrigin[VSC_NB_MAX_SUB_IMAGE];
	cv::Mat m_cvMatSubImage[VSC_NB_MAX_SUB_IMAGE];


	bool m_bParamLandscape;
	bool m_bParamAutoPaste;

	unsigned short m_usNbSubImage;
	unsigned short m_usSubRotate[VSC_NB_MAX_SUB_IMAGE];
	int m_TrimSubImageTop[VSC_NB_MAX_SUB_IMAGE];
	int m_TrimSubImageBottom[VSC_NB_MAX_SUB_IMAGE];
	int m_TrimSubImageLeft[VSC_NB_MAX_SUB_IMAGE];
	int m_TrimSubImageRight[VSC_NB_MAX_SUB_IMAGE];
	unsigned short m_usRotate;
	int m_TrimImageTop;
	int m_TrimImageBottom;
	int m_TrimImageLeft;
	int m_TrimImageRight;

	cv::Rect m_cvRectSubImage[VSC_NB_MAX_SUB_IMAGE];
	cv::Rect m_cvRectEndImage;

	cv::Rect m_cvAreaAutoPastle;
	int m_iPastleTheshold;

protected:

	void trimMatrix(cv::Mat & p_cvMatrix, int p_iTop, int p_iBottom, int p_iLeft, int p_iRight) const;
	void trimMatrix(cv::Mat & p_cvMatrix, const cv::Rect & p_cvRect) const;

	cv::Mat m_cvMatSubImageShape[VSC_NB_MAX_SUB_IMAGE];

	unsigned int m_uiCurrentIndex;
	double m_dScale;
	cv::Mat m_cvMatImage;

};

#endif // VSC_MAT_H

