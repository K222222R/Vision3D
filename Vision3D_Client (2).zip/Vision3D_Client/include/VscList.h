///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_LIST_H
#define VSC_LIST_H

#include "VscConst.h"

#include <rapidjson/document.h>

class VscObject;

class VscList
{
public:
	VscList();
	~VscList();

	bool load(const char * p_strName, const rapidjson::Value & p_jsonVal, bool p_pbModeFull = false);
	void save(const char * p_strName, rapidjson::Value & p_jsonVal, rapidjson::Document & p_jsonDoc, bool p_pbModeFull = false) const;

	bool isEmpty() const;

	void add(VscObject * p_ptItem);
	void remove(const VscObject * p_ptItem);
	void setItem(int p_iIndex, VscObject * p_ptItem);
	VscObject * getItem(unsigned int p_uiIndex) const;
	VscObject * findByGlobalIndex(int p_iIndex) const;

	int getIndex(const VscObject * p_ptItem) const;

	VscObject * getFree();

	void updateNbMax();
	void setNbMax(unsigned int p_uiNbMax);
	unsigned int getNbMax() const;


	void select(VscObject * p_ptItem);
	VscObject * getSelected();
	const VscObject * getSelected() const;

	void clear();


	bool isContains(const VscObject * p_ptObject) const;

protected:
	VscObject * m_ptItem[VSC_NB_MAX_OBJECT];

private:
	VscObject * m_tSelectedObject;
	unsigned int m_uiNbMaxObject;
};

#endif // VSC_LIST_H