///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_POINT_OF_INTERSECTION_H
#define VSC_POINT_OF_INTERSECTION_H

#include "VscPoint.h"
#include "VscList.h"
#include "VscMatZ.h"

class VscAxis;

class VscPointOfIntersection : public VscPoint
{
public:
	VscPointOfIntersection();
	virtual ~VscPointOfIntersection();

	static VscList * getList();

	virtual void updateMySelf(VscMatZ * p_cvMat) override;

	void setAxis(VscAxis * p_ptAxisA, VscAxis * p_ptAxisB);
	VscAxis * getAxisA() const;
	VscAxis * getAxisB() const;

private:
	static VscList m_list;

	VscAxis * m_ptAxisA;
	VscAxis * m_ptAxisB;
};

#endif // VSC_POINT_OF_INTERSECTION_H

