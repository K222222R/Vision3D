///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_IMAGE_Z_H
#define VSC_IMAGE_Z_H

#include "VscImage.h"
#include "VscMatZ.h"
#include "VscListShape.h"
#include "VscAlgoLibre.h"

class VscImageZ : public VscImage
{
public:
	// constructor
	VscImageZ();

	
	//void save();

	bool load(const rapidjson::Value & p_jsonVal);//const rapidjson::Value & p_jsonVal);
	void save(rapidjson::Value & p_jsonVal) const;// , rapidjson::Document & p_jsonDom);

	//void setView(Vision3D * p_ptVision);

	void write(cv::Mat1s & p_cvMatImageZ);
	//void reload();
	virtual void update(TReloadType p_tReloadType);

	VscMatZ * getMat();
	const VscMatZ * getMat() const;
	

	//void displayImage(QLabel * p_qtLabel, cv::Mat&  mat_with_shape);
	//void displayCalibrationParameters();
	

	void initViewParameters();
	void setViewParameters();
	//void displayViewParameters();


	virtual void displayShapes();
	virtual void displayViewSubImage(unsigned int p_uiIndexSubImag);

	

	//void display();

	void resetCurrentSubImage();
	
	//void addPoint(VscPointRef * p_ptPoint);

	void setAutoFill(bool p_bIsAuto);
	bool isAutoFill() const;
	void autoFill(cv::Mat1s & p_cvMatImageZ);
#if 0
	void setColorAuto(bool p_bIsAuto, int p_iMin = 0, int p_iMax = 100);
	bool isColorAuto() const;
	int getColorMin() const;
	int getColorMax() const;
#endif
	void setSeuilTapis(unsigned int p_uiSeuilTapis);
	unsigned int getSeuilTapis() const;

	void setNoCut(bool p_bIsNoCut);
	bool isNoCut() const;


	void setCorrectionValue(const cv::Point & p_pPts);
	void setCorrectionPoint(VscPoint * p_ptPoint);
	void setCorrection(bool p_bIsCorrection);
	bool isCorrection() const;
	bool isAlarm() const;
	void correction();
	const cv::Point & getCorrectionValue() const;
	VscPoint * getCorrectionPoint() const;
	void displayCorrection(VscMatZ * p_cvMat, cv::Mat & p_matRun);

	VscPoint * getAlarmPoint() const;

private:
	VscMatZ m_matZ;

	bool m_bIsRebouchageAuto;
	unsigned int m_uiSeuilTapis;

	cv::Point m_cvPtsTemp;
	VscPoint * m_ptsCorrection;
	bool m_bIsCorrection;
	bool m_bIsNoCut;
};

#endif // VSC_IMAGE_Z_H