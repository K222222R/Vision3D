///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_IMAGE_H
#define VSC_IMAGE_H

#include "VscList.h"
#include "VscObject.h"
#include "VscListShape.h"
#include "VscMat.h"
#include "VscAlgoLibre.h"
#include <qlistwidget.h>
#include <qtreewidget.h>

#include <qlabel.h>
#include <qmutex.h>
#include <rapidjson/document.h>

class VscPointRef;
class VscConfigFile;
class VscPoint;

class VscImage : public VscObject
{
public:
	VscImage();
	virtual ~VscImage() = 0;

	typedef enum {
		VSC_RELOAD_FULL = 0x00,
		VSC_RELOAD_EDIT_SHAPE,
		VSC_RELOAD_SELECT_SHAPE,
		VSC_RELOAD_ZOOM,
		VSC_RELOAD_MOVE_POINT
	} TReloadType;

	virtual void update(TReloadType p_tReloadType) = 0;

	void reload(TReloadType p_tReloadType);

	void addPoint(VscPointRef * p_ptPoint);

	bool calibration();

	void createTree();
	void clearTree();

	void display(TReloadType p_tReloadType);
	void displayImage(QLabel * p_qtLabel, cv::Mat&  mat_with_shape);
	void displayListes();
	void displayCorrectionListe();
	void displayCalibrationParameters();
	virtual void displayShapes() = 0;
	virtual void displayViewSubImage(unsigned int p_uiIndexSubImag) = 0;

	VscPoint * findReferencePoint();
	void setRealCoord(VscPoint * p_ptPoint);

	void setCalibThreshold(int p_iCalibThresholdX, int p_iCalibThresholdY, int p_iCalibThresholdZ);
	void getCalibThreshold(int & p_iCalibThresholdX, int & p_iCalibThresholdY, int & p_iCalibThresholdZ) const;

	int getImageNumber();
	VscAlgoLibre * getAlgoLibre();

	void sendToExternalInterface();
	void recvFromExternalInterface();

	void setAllowCorrection(bool p_bIsAllowCorrection);
	bool isAllowCorrection() const;

	static VscList * getList();

protected:
	QMutex m_mutex;
	VscListShape m_listPointRef;
	VscMat * m_ptMat;

	unsigned int m_uiCalibGapX;
	unsigned int m_uiCalibGapY;
	unsigned int m_uiCalibGapZ;

	//unsigned int m_uiCalibValueX;
	//unsigned int m_uiCalibValueY;
	unsigned int m_uiCalibValueZ;

	int m_iCalibThresholdX;
	int m_iCalibThresholdY;
	int m_iCalibThresholdZ;

	VscAlgoLibre m_algoLibre;

	int m_iImageNumber;

	bool m_bIsAllowCorrection;

private:
	
	static VscList m_list;

	QListWidgetItem m_ListWidgetPointCalib[VSC_NB_MAX_POINT];
	QListWidgetItem m_ListWidgetShapeRun[VSC_NB_MAX_SHAPE];
	//QListWidgetItem m_ListWidgetShapeEdit[VSC_NB_MAX_SHAPE];
	//QListWidgetItem m_ListWidgetAreaEdit[VSC_NB_MAX_AREA];
	QListWidgetItem m_ListWidgetMovePoint[VSC_NB_MAX_SHAPE];
	
	
	//QTreeWidgetItem m_treeWidgetShapeEdit[VSC_NB_MAX_SHAPE];

	
	QTreeWidgetItem m_treeWidgetShapeEdit[VSC_NB_MAX_SHAPE][VSC_NB_MAX_SHAPE];
};

#endif // VSC_IMAGE_H

