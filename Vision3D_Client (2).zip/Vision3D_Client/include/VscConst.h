///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_CONST_H
#define VSC_CONST_H

#define VSC_PASSWORD_MODE_INTEGRATOR			"saturn"
#define VSC_PASSWORD_MODE_SETTING				"neptune"

//#define VSC_VISION3D_VERSION					"2.11"			// Correction du nombre maximum de point de point (max pass� � 100 au lieu de 50). Modification de la vue Aper�u afin d'avoir un meilleur rendu sur ecran 16:9.
//#define VSC_VISION3D_VERSION					"2.12"			// Correction faute d'orthographe dans la fen�tre � propos. Changement de la m�thode de calcul des points en fonction des fronts. Les points invalides sont pris en compte et pour les fronts descendants la valeur est remplac�e par seuil tapis.
//#define VSC_VISION3D_VERSION					"2.13"			// Redefinition de la plage des registres modbus + correction modbus algo libre.
//#define VSC_VISION3D_VERSION					"2.14"			// Emission vers modbus des infos "ne pas decouper" et "correction en cours"
#define VSC_VISION3D_VERSION					"2.15"			// Ajout de l'evolution "Valeur absolue" pour les points cr��s � partir des points.
#define VSC_VISION3D_DATE						"02/07/2020"

#define VSC_VISION3D_CONFIG_MIN_VERSION			"2.03"

#define VSC_SIZE_MAX_LOG_WENGLOR				(1024 * 1024 * 1024) // 1 go de log max

#define VSC_NB_MAX_SUB_IMAGE					4

#define VSC_NB_MAX_AREA							50
#define VSC_NB_MAX_AXIS							50

#define VSC_NB_MAX_POINT_REF					50
#define VSC_NB_MAX_POINT_CHILDREN				100
#define VSC_NB_MAX_POINT_OF_AXIS				50
#define VSC_NB_MAX_POINT_OF_INTERSECTION		50
#define VSC_NB_MAX_POINT_AREA					(10 * VSC_NB_MAX_AREA) + 78		// TODO : Remplacer cette ligne par 50 le jour ou le fichier de configuration sera reinit
#define VSC_NB_MAX_POINT						(VSC_NB_MAX_POINT_REF + VSC_NB_MAX_POINT_CHILDREN + VSC_NB_MAX_POINT_AREA + VSC_NB_MAX_POINT_OF_AXIS + VSC_NB_MAX_POINT_OF_INTERSECTION)

#define VSC_NB_MAX_SHAPE						(VSC_NB_MAX_AREA + VSC_NB_MAX_AXIS + VSC_NB_MAX_POINT)

#define VSC_NB_MAX_INTERFACE					4
#define VSC_NB_MAX_IMAGE						2

#define VSC_NB_MAX_ITEM							(VSC_NB_MAX_SHAPE + VSC_NB_MAX_INTERFACE + VSC_NB_MAX_IMAGE)
#define VSC_NB_MAX_OBJECT						VSC_NB_MAX_ITEM


#define VSC_NB_MAX_MODBUS_RECV_REGISTER			200
#define VSC_NB_MAX_MODBUS_SEND_REGISTER			300
#define VSC_NB_MAX_MODBUS_REGISTER				(VSC_NB_MAX_MODBUS_RECV_REGISTER + VSC_NB_MAX_MODBUS_SEND_REGISTER)

enum {
	VSC_INTERFACE_CAMERA_IFM			= 0x00,
	VSC_INTERFACE_CAMERA_LOG_IMAGE_Z,
	VSC_INTERFACE_CAMERA_WENGLOR_MLS255,
	VSC_INTERFACE_CAMERA_WENGLOR_MLS255_LOG,
	VSC_INTERFACE_EXTERNE_MODBUS,
};

#define VSC_INVALID_VALUE				((unsigned int)0xFFFFFFFF)

#endif // VSC_CONST_H