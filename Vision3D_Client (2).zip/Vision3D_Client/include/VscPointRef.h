///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_POINT_REF_H
#define VSC_POINT_REF_H

#include "VscPoint.h"

//#include <rapidjson/document.h>
#include "VscListShape.h"

class VscPointRef :	public VscPoint
{
public:
	VscPointRef();
	virtual ~VscPointRef();

	static VscListShape * getList();

	virtual bool load(const rapidjson::Value & p_jsonVal) override;
	virtual void save(rapidjson::Value & p_jsonVal) const override;

	virtual void displayViewParameters(bool p_bChangedView) const override;

	void setXY(int p_iX, int p_iY);
	void setXY(const cv::Point & p_pcvPts);

private:
	static VscListShape m_list;
};

#endif // VSC_POINT_REF_H

