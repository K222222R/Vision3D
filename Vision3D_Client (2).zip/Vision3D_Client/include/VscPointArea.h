///
/// \author Frederic Vrignaud (https://fvrignaud.vsconnect.fr)
/// \brief Application Vision3D d�velopp�e pour Chesnel Automatismes (chesnel.automatimes@orange.fr)
///

#ifndef VSC_POINT_AREA_H
#define VSC_POINT_AREA_H

#include "VscPoint.h"
#include "VscList.h"

class VscPointArea : public VscPoint
{
public:

	typedef enum {
		VSC_POINT_AREA_INTERNAL_X_MIN = 0x00,
		VSC_POINT_AREA_INTERNAL_X_MAX,
		VSC_POINT_AREA_INTERNAL_Y_MIN,
		VSC_POINT_AREA_INTERNAL_Y_MAX,
		VSC_POINT_AREA_EXTERNAL_X_MIN,
		VSC_POINT_AREA_EXTERNAL_X_MAX,
		VSC_POINT_AREA_EXTERNAL_Y_MIN,
		VSC_POINT_AREA_EXTERNAL_Y_MAX,
		VSC_POINT_AREA_TYPE_NB_MAX
	} TPointAreaType;

	VscPointArea();
	virtual ~VscPointArea();

	static VscList * getList();

	virtual bool load(const rapidjson::Value & p_jsonVal) override;
	virtual void save(rapidjson::Value & p_jsonVal) const override;

	virtual void updateMySelf(VscMatZ * p_cvMat) override;

	virtual void displayViewParameters(bool p_bChangedView) const override;

	void setInternalMinX(int p_iAverage);
	void setInternalMaxX(int p_iAverage);
	void setExternalMinX(int p_iAverage);
	void setExternalMaxX(int p_iAverage);
	void setInternalMinY(int p_iAverage);
	void setInternalMaxY(int p_iAverage);
	void setExternalMinY(int p_iAverage);
	void setExternalMaxY(int p_iAverage);

	bool isInternalMinX() const;
	bool isInternalMaxX() const;
	bool isExternalMinX() const;
	bool isExternalMaxX() const;
	bool isInternalMinY() const;
	bool isInternalMaxY() const;
	bool isExternalMinY() const;
	bool isExternalMaxY() const;

	int getAverage() const;

private:

	void setXY(const cv::Point & p_pcvPts);

	static VscList m_list;

	TPointAreaType m_eTool;

	int m_iAverage;
};

#endif // VSC_POINT_AREA_H
